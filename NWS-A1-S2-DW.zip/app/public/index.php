<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partiel  A1 Semestre 2: Cas pratique DW</title>
    <!-- Styles -->
    <link rel="stylesheet" href="/css/styles.css">
    <!-- Scripts -->
    <script src="/js/scripts.js" defer></script>
</head>
<body>
    <h1>Partiel  A1 Semestre 2: Cas pratique DW</h1>
    <p>Bon courage ! 💪</p>
</body>
</html>