// Créez votre code JavaScript ici
console.log('Hello from scripts.js!'); // Vous pouvez supprimer cette ligne